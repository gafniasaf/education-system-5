// Pages index
// [pkg-09-pages-index]

export { AdminAuditLogsPage } from './AdminAuditLogsPage';
export type { AdminAuditLogsPageProps } from './AdminAuditLogsPage';

export { FilesPage } from './FilesPage';
export type { FilesPageProps } from './FilesPage';